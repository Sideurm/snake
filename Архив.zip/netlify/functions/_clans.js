const { query } = require("./_db");

let clansSchemaReady = false;
const MONTH_TARGET_WINS = 300;

function monthKeyUTC(now = new Date()) {
  const y = now.getUTCFullYear();
  const m = String(now.getUTCMonth() + 1).padStart(2, "0");
  return `${y}-${m}`;
}

function normalizeClanName(value) {
  return String(value || "").trim().replace(/\s+/g, " ");
}

function normalizeClanNameKey(value) {
  return normalizeClanName(value).toLowerCase();
}

function validateClanName(name) {
  if (typeof name !== "string") return false;
  const trimmed = normalizeClanName(name);
  if (trimmed.length < 3 || trimmed.length > 24) return false;
  return /^[\p{L}\p{N}_\-\s]+$/u.test(trimmed);
}

async function ensureClansSchema() {
  if (clansSchemaReady) return;

  await query(`
    create table if not exists clans (
      id bigserial primary key,
      name text not null,
      name_norm text not null unique,
      owner_user_id bigint not null references users(id) on delete cascade,
      created_at timestamptz not null default now()
    );
  `);

  await query(`
    create table if not exists clan_members (
      clan_id bigint not null references clans(id) on delete cascade,
      user_id bigint not null references users(id) on delete cascade,
      role text not null default 'member',
      joined_at timestamptz not null default now(),
      primary key (clan_id, user_id),
      unique (user_id),
      constraint clan_members_role_check check (role in ('owner', 'member'))
    );
  `);

  await query(`
    create table if not exists clan_monthly_progress (
      clan_id bigint not null references clans(id) on delete cascade,
      month_key text not null,
      wins integer not null default 0,
      updated_at timestamptz not null default now(),
      primary key (clan_id, month_key)
    );
  `);

  await query(`
    create table if not exists clan_monthly_claims (
      clan_id bigint not null references clans(id) on delete cascade,
      month_key text not null,
      user_id bigint not null references users(id) on delete cascade,
      claimed_at timestamptz not null default now(),
      primary key (clan_id, month_key, user_id)
    );
  `);

  await query(`
    create table if not exists clan_win_events (
      id bigserial primary key,
      clan_id bigint not null references clans(id) on delete cascade,
      user_id bigint not null references users(id) on delete cascade,
      created_at timestamptz not null default now()
    );
  `);

  await query(`create index if not exists idx_clan_members_clan_id on clan_members(clan_id);`);
  await query(`create index if not exists idx_clan_monthly_progress_month on clan_monthly_progress(month_key, wins desc);`);
  await query(`create index if not exists idx_clan_win_events_user_created on clan_win_events(user_id, created_at desc);`);

  clansSchemaReady = true;
}

async function getUserClan(userId) {
  const result = await query(
    `select c.id, c.name, c.owner_user_id, cm.role
     from clan_members cm
     join clans c on c.id = cm.clan_id
     where cm.user_id = $1
     limit 1`,
    [userId]
  );
  if (result.rowCount === 0) return null;
  const row = result.rows[0];
  return {
    id: Number(row.id),
    name: row.name,
    ownerUserId: Number(row.owner_user_id),
    role: row.role
  };
}

async function getClanMembers(clanId) {
  const result = await query(
    `select cm.user_id, cm.role, cm.joined_at, u.nickname, u.email
     from clan_members cm
     join users u on u.id = cm.user_id
     where cm.clan_id = $1
     order by cm.joined_at asc`,
    [clanId]
  );
  return result.rows.map((row) => ({
    userId: Number(row.user_id),
    role: row.role,
    joinedAt: row.joined_at ? new Date(row.joined_at).toISOString() : null,
    nickname: row.nickname || null,
    email: row.email || null
  }));
}

module.exports = {
  MONTH_TARGET_WINS,
  monthKeyUTC,
  normalizeClanName,
  normalizeClanNameKey,
  validateClanName,
  ensureClansSchema,
  getUserClan,
  getClanMembers
};
