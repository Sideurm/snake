const { query } = require("./_db");
const { extractBearerToken, verifyToken } = require("./_auth");
const { json, methodNotAllowed, unauthorized, badRequest, internalError } = require("./_http");
const { ensureClansSchema, getUserClan, monthKeyUTC, MONTH_TARGET_WINS } = require("./_clans");

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return methodNotAllowed();

  try {
    const token = extractBearerToken(event.headers);
    const payload = verifyToken(token);
    if (!payload) return unauthorized("invalid_token");

    await ensureClansSchema();

    const clan = await getUserClan(payload.uid);
    if (!clan) return badRequest("not_in_clan");

    const monthKey = monthKeyUTC();
    const progressResult = await query(
      `select wins from clan_monthly_progress where clan_id = $1 and month_key = $2 limit 1`,
      [clan.id, monthKey]
    );
    const wins = progressResult.rowCount ? Number(progressResult.rows[0].wins || 0) : 0;
    if (wins < MONTH_TARGET_WINS) return badRequest("target_not_reached");

    const inserted = await query(
      `insert into clan_monthly_claims(clan_id, month_key, user_id)
       values($1, $2, $3)
       on conflict do nothing
       returning user_id`,
      [clan.id, monthKey, payload.uid]
    );
    if (inserted.rowCount === 0) return badRequest("already_claimed");

    const rewards = {
      commonBoxes: 5,
      rareBoxes: 3,
      superBoxes: Math.random() < 0.4 ? 1 : 0
    };

    return json(200, {
      ok: true,
      monthKey,
      wins,
      targetWins: MONTH_TARGET_WINS,
      rewards
    });
  } catch (error) {
    return internalError(error);
  }
};
