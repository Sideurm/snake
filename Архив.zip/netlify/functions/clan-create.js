const { query } = require("./_db");
const { extractBearerToken, verifyToken } = require("./_auth");
const { json, methodNotAllowed, unauthorized, badRequest, internalError, parseBody } = require("./_http");
const { ensureClansSchema, getUserClan, normalizeClanName, normalizeClanNameKey, validateClanName } = require("./_clans");

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return methodNotAllowed();

  try {
    const token = extractBearerToken(event.headers);
    const payload = verifyToken(token);
    if (!payload) return unauthorized("invalid_token");

    await ensureClansSchema();

    const body = parseBody(event);
    if (!body) return badRequest("invalid_json");

    const name = normalizeClanName(body.name);
    const nameNorm = normalizeClanNameKey(name);
    if (!validateClanName(name)) return badRequest("invalid_clan_name");

    const existing = await getUserClan(payload.uid);
    if (existing) return badRequest("already_in_clan");

    const created = await query(
      `insert into clans(name, name_norm, owner_user_id)
       values($1, $2, $3)
       returning id`,
      [name, nameNorm, payload.uid]
    ).catch((error) => {
      if (error && error.code === "23505") return null;
      throw error;
    });

    if (!created || created.rowCount === 0) return badRequest("clan_name_taken");

    const clanId = Number(created.rows[0].id);
    await query(
      `insert into clan_members(clan_id, user_id, role)
       values($1, $2, 'owner')`,
      [clanId, payload.uid]
    );

    return json(200, { ok: true, clanId });
  } catch (error) {
    return internalError(error);
  }
};
