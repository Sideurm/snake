const { query } = require("./_db");
const { extractBearerToken, verifyToken } = require("./_auth");
const { json, methodNotAllowed, unauthorized, internalError } = require("./_http");
const { ensureClansSchema, getUserClan, getClanMembers, monthKeyUTC, MONTH_TARGET_WINS } = require("./_clans");

exports.handler = async (event) => {
  if (event.httpMethod !== "GET") return methodNotAllowed();

  try {
    const token = extractBearerToken(event.headers);
    const payload = verifyToken(token);
    if (!payload) return unauthorized("invalid_token");

    await ensureClansSchema();

    const clan = await getUserClan(payload.uid);
    if (!clan) {
      return json(200, { ok: true, clan: null, monthKey: monthKeyUTC(), targetWins: MONTH_TARGET_WINS });
    }

    const monthKey = monthKeyUTC();
    const progressResult = await query(
      `select wins from clan_monthly_progress where clan_id = $1 and month_key = $2 limit 1`,
      [clan.id, monthKey]
    );
    const wins = progressResult.rowCount ? Number(progressResult.rows[0].wins || 0) : 0;

    const claimedResult = await query(
      `select 1 from clan_monthly_claims where clan_id = $1 and month_key = $2 and user_id = $3 limit 1`,
      [clan.id, monthKey, payload.uid]
    );

    const members = await getClanMembers(clan.id);

    return json(200, {
      ok: true,
      monthKey,
      targetWins: MONTH_TARGET_WINS,
      clan: {
        ...clan,
        members,
        wins,
        claimed: claimedResult.rowCount > 0,
        canClaim: wins >= MONTH_TARGET_WINS && claimedResult.rowCount === 0
      }
    });
  } catch (error) {
    return internalError(error);
  }
};
